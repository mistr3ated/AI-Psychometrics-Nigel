import os, numpy as np, pandas as pd
from itertools import combinations
from sentence_transformers import SentenceTransformer
from sklearn.metrics.pairwise import cosine_similarity

np.random.seed(3141)
df      = pd.read_csv('collapse.csv')
embs    = SentenceTransformer('all-MiniLM-L6-v2').encode(df['item'].tolist())
dim     = embs.shape[1]
noise   = np.random.normal(0, 1, embs.shape).astype(np.float32)
factors = ['EX', 'AG', 'CO', 'EM', 'IN']
perms   = {f: {j: np.random.permutation(dim)
               for j in np.where(df['code'].str.startswith(f).values)[0]}
           for f in factors}

def make_matrix(noised=(), scrambled=()):
    e = embs.copy()
    for f in noised:
        e[df['code'].str.startswith(f).values] = noise[df['code'].str.startswith(f).values]
    for f in scrambled:
        for j, p in perms[f].items(): e[j] = e[j][p]
    return pd.DataFrame(cosine_similarity(e), index=df['code'], columns=df['code'])

make_matrix().to_csv('sim_matrix.csv')
for i in range(len(factors)):
    name = '_'.join(f.lower() for f in factors[:i+1])
    make_matrix(noised=factors[:i+1]).to_csv(f'noisy_{name}.csv')
    make_matrix(scrambled=factors[:i+1]).to_csv(f'scr_{name}.csv')

os.makedirs('subsets', exist_ok=True)
for r in range(1, 6):
    for combo in combinations(factors, r):
        name = '_'.join(f.lower() for f in combo)
        make_matrix(noised=combo).to_csv(f'subsets/noise_{name}.csv')
        make_matrix(scrambled=combo).to_csv(f'subsets/scr_{name}.csv')

print('Done')
