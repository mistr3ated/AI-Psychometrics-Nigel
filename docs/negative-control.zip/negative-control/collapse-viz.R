library(esemComp)
library(ggplot2)
library(reshape2)
library(patchwork)

symm <- function(m) { m[upper.tri(m)] <- t(m)[upper.tri(m)]; rownames(m) <- colnames(m); m }

var_order <- c("EX1","EX2","EX3","EX4","EX5","EX6R","EX7R","EX8R","EX9R","EX10R",
               "AG11","AG12","AG13","AG14","AG15","AG16","AG17R","AG18R","AG19R","AG20R",
               "CO21","CO22","CO23","CO24","CO25","CO26","CO27R","CO28R","CO29R","CO30R",
               "EM31","EM32","EM33R","EM34R","EM35R","EM36R","EM37R","EM38R","EM39R","EM40R",
               "IN41","IN42","IN43","IN44","IN45","IN46","IN47","IN48R","IN49R","IN50R")

groups <- list(EX = var_order[1:10],  AG = var_order[11:20], CO = var_order[21:30],
               EM = var_order[31:40], IN = var_order[41:50])

target.mat <- matrix(0, nrow = 50, ncol = 5, dimnames = list(var_order, names(groups)))
for (g in names(groups)) target.mat[groups[[g]], g] <- 1

daal_assign <- function(L, groups) {
  d <- sapply(names(groups), function(g) colMeans(abs(L[groups[[g]], , drop = FALSE])))
  apply(d, 2, which.max)
}

daal_recover <- function(L, groups, floor = 0.25) {
  d      <- sapply(names(groups), function(g) colMeans(abs(L[groups[[g]], , drop = FALSE])))
  winner <- apply(d, 2, which.max)
  ok     <- apply(d, 2, max) >= floor
  winner[!ok] <- NA
  dups   <- !is.na(winner) & (duplicated(winner, incomparables = NA) | duplicated(winner, fromLast = TRUE, incomparables = NA))
  sum(ok & !dups)
}

short_labels <- c('Baseline', '+EX', '+AG', '+CO', '+EM', '+IN')
step_labels  <- c('Baseline', '+Noise EX', '+Noise EX+AG', '+Noise EX+AG+CO',
                  '+Noise EX+AG+CO+EM', '+Noise All')

nfiles <- c('sim_matrix.csv', 'noisy_ex.csv', 'noisy_ex_ag.csv',
            'noisy_ex_ag_co.csv', 'noisy_ex_ag_co_em.csv', 'noisy_ex_ag_co_em_in.csv')
sfiles <- c('sim_matrix.csv', 'scr_ex.csv', 'scr_ex_ag.csv',
            'scr_ex_ag_co.csv', 'scr_ex_ag_co_em.csv', 'scr_ex_ag_co_em_in.csv')

fits_n <- lapply(nfiles, function(f) suppressWarnings(
  esem_efa(symm(as.matrix(read.csv(f, row.names = 1))[var_order, var_order]),
           nfactors = 5, target = target.mat, targetAlgorithm = 'targetQ', fm = 'ml', maxit = 10000)))
fits_s <- lapply(sfiles, function(f) suppressWarnings(
  esem_efa(symm(as.matrix(read.csv(f, row.names = 1))[var_order, var_order]),
           nfactors = 5, target = target.mat, targetAlgorithm = 'targetQ', fm = 'ml', maxit = 10000)))

recovery_n <- sapply(fits_n, function(fit) daal_recover(fit$loadings[], groups))
recovery_s <- sapply(fits_s, function(fit) daal_recover(fit$loadings[], groups))

# --- Figure 1: Recovery comparison ---
df_rec <- rbind(
  data.frame(step = factor(short_labels, levels = short_labels), recovered = recovery_n, method = 'Noise injection'),
  data.frame(step = factor(short_labels, levels = short_labels), recovered = recovery_s, method = 'Dimension scramble')
)

p1 <- ggplot(df_rec, aes(x = step, y = recovered, colour = method, group = method)) +
  geom_line(linewidth = 1.2) +
  geom_point(size = 4) +
  scale_colour_manual(values = c('Noise injection' = '#2166ac', 'Dimension scramble' = '#d73027')) +
  scale_y_continuous(limits = c(-0.3, 5.8), breaks = 0:5, labels = paste0(0:5, '/5')) +
  labs(x = NULL, y = 'Factors recovered', colour = NULL,
       title = 'Factor recovery collapses as semantic signal is destroyed',
       subtitle = 'DAAL floor = 0.25; both perturbation methods give identical results') +
  theme_minimal(base_size = 13) +
  theme(panel.grid.minor  = element_blank(),
        plot.title        = element_text(face = 'bold'),
        legend.position   = 'bottom')

ggsave('fig1_recovery.png', p1, width = 8, height = 4.5, dpi = 150)
cat('fig1_recovery.png saved\n')

# --- Figure 2: Loading heatmap (noise steps) ---
make_loading_df <- function(fit, step_label) {
  L      <- fit$loadings[]
  assign <- daal_assign(L, groups)
  L_ord  <- L[, assign]
  colnames(L_ord) <- names(groups)
  df <- melt(L_ord, varnames = c('item', 'factor'), value.name = 'loading')
  df$item  <- factor(df$item, levels = rev(var_order))
  df$step  <- step_label
  df
}

load_df      <- do.call(rbind, mapply(make_loading_df, fits_n, step_labels, SIMPLIFY = FALSE))
load_df$step <- factor(load_df$step, levels = step_labels)

p2 <- ggplot(load_df, aes(x = factor, y = item, fill = abs(loading))) +
  geom_tile(colour = NA) +
  facet_wrap(~step, nrow = 2) +
  scale_fill_gradient(low = '#4575b4', high = '#d73027', limits = c(0, 1), name = '|Loading|') +
  geom_hline(yintercept = c(10.5, 20.5, 30.5, 40.5), colour = 'grey40', linewidth = 0.3) +
  labs(x = NULL, y = NULL,
       title = 'Factor loadings at each perturbation step (noise)',
       subtitle = 'Items grouped by true factor (EX top → IN bottom); columns aligned to theoretical factors') +
  theme_minimal(base_size = 11) +
  theme(axis.text.y        = element_text(size = 5.5),
        axis.text.x        = element_text(size = 10, face = 'bold'),
        strip.text         = element_text(size = 9, face = 'bold'),
        panel.spacing      = unit(0.6, 'lines'),
        plot.title         = element_text(face = 'bold'),
        plot.background    = element_rect(fill = 'white', colour = NA),
        panel.background   = element_rect(fill = 'white', colour = NA))

ggsave('fig2_loadings.png', p2, width = 13, height = 11, dpi = 150)
cat('fig2_loadings.png saved\n')

# --- Figure 3: Similarity matrix evolution (noise steps) ---
sim_df <- do.call(rbind, mapply(function(f, lbl) {
  m  <- symm(as.matrix(read.csv(f, row.names = 1))[var_order, var_order])
  df <- melt(m, varnames = c('item1', 'item2'), value.name = 'similarity')
  df$item1 <- factor(df$item1, levels = rev(var_order))
  df$item2 <- factor(df$item2, levels = var_order)
  df$step  <- lbl
  df
}, nfiles, step_labels, SIMPLIFY = FALSE))
sim_df$step <- factor(sim_df$step, levels = step_labels)

dividers <- c(10.5, 20.5, 30.5, 40.5)

p3 <- ggplot(sim_df, aes(x = item2, y = item1, fill = similarity)) +
  geom_tile() +
  facet_wrap(~step, nrow = 2) +
  scale_fill_gradient2(low = '#4575b4', mid = 'white', high = '#d73027',
                       midpoint = 0.25, limits = c(0.15, 0.35),
                       oob = scales::squish, name = 'Cosine\nsimilarity') +
  geom_hline(yintercept = dividers, colour = 'grey50', linewidth = 0.3) +
  geom_vline(xintercept = dividers, colour = 'grey50', linewidth = 0.3) +
  labs(x = NULL, y = NULL,
       title = 'Cosine similarity matrix at each perturbation step',
       subtitle = 'Items ordered EX → AG → CO → EM → IN; block structure visible at baseline') +
  theme_minimal(base_size = 11) +
  theme(axis.text         = element_blank(),
        axis.ticks        = element_blank(),
        strip.text        = element_text(size = 9, face = 'bold'),
        panel.spacing     = unit(0.4, 'lines'),
        plot.title        = element_text(face = 'bold'),
        plot.background   = element_rect(fill = 'white', colour = NA),
        panel.background  = element_rect(fill = 'white', colour = NA))

ggsave('fig3_simmatrix.png', p3, width = 13, height = 9, dpi = 150)
cat('fig3_simmatrix.png saved\n')
