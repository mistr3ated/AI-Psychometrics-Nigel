library(esemComp)

symm    <- function(m) { m[upper.tri(m)] <- t(m)[upper.tri(m)]; rownames(m) <- colnames(m); m }
read_m  <- function(f) symm(as.matrix(read.csv(f, row.names=1))[var_order, var_order])
run_efa <- function(m) suppressWarnings(esem_efa(m, nfactors=5, target=target.mat,
                                                  targetAlgorithm='targetQ', fm='ml', maxit=10000))

var_order <- c("EX1","EX2","EX3","EX4","EX5","EX6R","EX7R","EX8R","EX9R","EX10R",
               "AG11","AG12","AG13","AG14","AG15","AG16","AG17R","AG18R","AG19R","AG20R",
               "CO21","CO22","CO23","CO24","CO25","CO26","CO27R","CO28R","CO29R","CO30R",
               "EM31","EM32","EM33R","EM34R","EM35R","EM36R","EM37R","EM38R","EM39R","EM40R",
               "IN41","IN42","IN43","IN44","IN45","IN46","IN47","IN48R","IN49R","IN50R")
groups <- list(EX=var_order[1:10], AG=var_order[11:20], CO=var_order[21:30],
               EM=var_order[31:40], IN=var_order[41:50])
target.mat <- matrix(0, 50, 5, dimnames=list(var_order, names(groups)))
for (g in names(groups)) target.mat[groups[[g]], g] <- 1

daal <- function(L, floor=0.25) {
  d      <- sapply(names(groups), function(g) colMeans(abs(L[groups[[g]],,drop=FALSE])))
  winner <- apply(d, 2, which.max); ok <- apply(d, 2, max) >= floor; winner[!ok] <- NA
  dups   <- !is.na(winner) & (duplicated(winner, incomparables=NA) |
                               duplicated(winner, fromLast=TRUE, incomparables=NA))
  sum(ok & !dups)
}

factors <- c('EX','AG','CO','EM','IN')
nfiles  <- c('sim_matrix.csv', paste0('noisy_', c('ex','ex_ag','ex_ag_co','ex_ag_co_em','ex_ag_co_em_in'), '.csv'))
sfiles  <- c('sim_matrix.csv', paste0('scr_',   c('ex','ex_ag','ex_ag_co','ex_ag_co_em','ex_ag_co_em_in'), '.csv'))

# --- Sequential recovery ---
fits_n <- lapply(nfiles, function(f) run_efa(read_m(f)))
fits_s <- lapply(sfiles, function(f) run_efa(read_m(f)))

cat(sprintf('%-10s  Noise  Scramble\n', 'Step'))
steps <- c('baseline','+EX','+AG','+CO','+EM','+IN')
for (i in seq_along(steps))
  cat(sprintf('%-10s  %d/5    %d/5\n', steps[i],
              daal(fits_n[[i]]$loadings[]), daal(fits_s[[i]]$loadings[])))

# --- Ordering check: all 120 orderings across 32 subsets ---
key <- function(v) paste(tolower(factors[sort(match(v, factors))]), collapse='_')

rec_n <- list(baseline = daal(fits_n[[1]]$loadings[]))
rec_s <- list(baseline = daal(fits_s[[1]]$loadings[]))
for (r in 1:5)
  for (combo in combn(factors, r, simplify=FALSE)) {
    k <- paste(tolower(combo), collapse='_')
    rec_n[[k]] <- daal(run_efa(read_m(paste0('subsets/noise_', k, '.csv')))$loadings[])
    rec_s[[k]] <- daal(run_efa(read_m(paste0('subsets/scr_',   k, '.csv')))$loadings[])
  }

all_perms <- function(v) if (length(v)==1) list(v) else
  unlist(lapply(seq_along(v), function(i) lapply(all_perms(v[-i]), function(p) c(v[i],p))),
         recursive=FALSE)

non_mono <- function(rec) sum(sapply(all_perms(factors), function(ord) {
  vals <- c(rec[['baseline']], sapply(1:5, function(k) rec[[key(ord[1:k])]]))
  any(diff(vals) > 0)
}))

cat(sprintf('\nOrdering check — 120 orderings, 31 subsets:\n'))
cat(sprintf('  Noise injection:    %d/120 non-monotonic\n', non_mono(rec_n)))
cat(sprintf('  Dimension scramble: %d/120 non-monotonic\n', non_mono(rec_s)))
