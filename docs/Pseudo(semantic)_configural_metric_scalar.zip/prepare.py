"""
prepare.py - translate SC items, embed, compute cosine matrices and pseudo means.

Outputs:
  item_translations.csv
  cosim_en.csv, cosim_es.csv, cosim_es_an.csv, cosim_es_dial.csv
  pmeans.csv
"""
from pathlib import Path
import time

import numpy as np
import pandas as pd
from deep_translator import GoogleTranslator
from sentence_transformers import SentenceTransformer
from sklearn.metrics.pairwise import cosine_similarity


OUT = Path(__file__).resolve().parent

ITEMS = [
    ("SCUP104", "Have weird perceptions."),
    ("SCCD71", "Have unusual thought processes."),
    ("SCUB69", "Have unconventional beliefs."),
    ("SCEC34", "Seem eccentric to other people."),
    ("SCDS108", "Wonder why I do the things I do."),
    ("SCUP32", "Have bizarre experiences."),
    ("SCEC106", "Have peculiar mannerisms."),
    ("SCDS72", "Forget how I got places."),
]
IDS, TEXTS = zip(*ITEMS)

tr = GoogleTranslator(source="en", target="es")
ES = [tr.translate(t) for t in TEXTS]
time.sleep(0.2)

loading_replacement_en = "See how far I can push people."
intercept_replacement_en = "Seem original to other people."
loading_replacement_es = tr.translate(loading_replacement_en)
intercept_replacement_es = tr.translate(intercept_replacement_en)

ES_AN = [
    loading_replacement_es if item_id == "SCUP32" else es
    for item_id, es in zip(IDS, ES)
]
ES_DIAL = [
    intercept_replacement_es if item_id == "SCEC34" else es
    for item_id, es in zip(IDS, ES)
]

translation_audit = pd.DataFrame(
    {
        "item_id": IDS,
        "english": TEXTS,
        "spanish_faithful": ES,
        "spanish_loading_condition": ES_AN,
        "spanish_intercept_condition": ES_DIAL,
        "loading_replacement_english": [
            loading_replacement_en if item_id == "SCUP32" else ""
            for item_id in IDS
        ],
        "intercept_replacement_english": [
            intercept_replacement_en if item_id == "SCEC34" else ""
            for item_id in IDS
        ],
    }
)
translation_audit.to_csv(OUT / "item_translations.csv", index=False)

print("Translations saved to item_translations.csv")
print(translation_audit.to_string(index=False))

model = SentenceTransformer("paraphrase-multilingual-MiniLM-L12-v2")
axis = model.encode("Weird", show_progress_bar=False) - model.encode(
    "Normal", show_progress_bar=False
)
axis /= np.linalg.norm(axis)

pm = {"item_id": list(IDS)}
for tag, texts in [
    ("en", TEXTS),
    ("es", ES),
    ("es_an", ES_AN),
    ("es_dial", ES_DIAL),
]:
    embeddings = model.encode(list(texts), show_progress_bar=False)
    pd.DataFrame(cosine_similarity(embeddings), index=IDS, columns=IDS).to_csv(
        OUT / f"cosim_{tag}.csv"
    )
    pm[tag] = embeddings @ axis

pd.DataFrame(pm).to_csv(OUT / "pmeans.csv", index=False)
print("Data written: cosim_en/es/es_an/es_dial.csv and pmeans.csv")
