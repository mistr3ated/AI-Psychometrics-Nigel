suppressPackageStartupMessages(library(lavaan))

# This mirrors fit.R's workaround for environments where lavaan caches
# an invalid default when parallel::detectCores() returns NA.
invisible(lavOptions())
lavaan_cache <- get("lavaan_cache_env", asNamespace("lavaan"))
lavaan_defaults <- get("opt.default", lavaan_cache)
lavaan_checks <- get("opt.check", lavaan_cache)
lavaan_defaults$ncpus <- 1L
lavaan_checks$ncpus$nm$bounds <- c(1, 1)
assign("opt.default", lavaan_defaults, lavaan_cache)
assign("opt.check", lavaan_checks, lavaan_cache)

args <- commandArgs(FALSE)
file_arg <- args[grepl("^--file=", args)]
DIR <- if (length(file_arg) > 0) {
  dirname(normalizePath(sub("^--file=", "", file_arg[1])))
} else {
  getwd()
}

PLOT_DIR <- file.path(DIR, "plots")
dir.create(PLOT_DIR, showWarnings = FALSE)

IDS <- c("SCUP104","SCCD71","SCUB69","SCEC34","SCDS108","SCUP32","SCEC106","SCDS72")

load_cosim <- function(tag) {
  m <- as.matrix(read.csv(file.path(DIR, paste0("cosim_", tag, ".csv")), row.names=1))
  colnames(m) <- rownames(m) <- IDS
  m
}

pmeans <- read.csv(file.path(DIR, "pmeans.csv"))
translations <- read.csv(file.path(DIR, "item_translations.csv"), stringsAsFactors=FALSE)

build_data <- function(en_mat, es_mat, en_pm, es_pm) {
  list(en=list(cov=en_mat, mean=en_pm, nobs=length(IDS)),
       es=list(cov=es_mat, mean=es_pm, nobs=length(IDS)))
}

model <- paste("F =~", paste(IDS, collapse=" + "), "\nF ~ c(0,NA)*1\nF ~~ c(1,NA)*F")

fit_free <- function(en_mat, es_mat, es_pm) {
  fit_mg(en_mat, es_mat, es_pm, character(0))
}

fit_mg <- function(en_mat, es_mat, es_pm, equal) {
  data <- build_data(en_mat, es_mat, pmeans$en, es_pm)
  sem(model, sample.cov=lapply(data, `[[`, "cov"),
      sample.mean=lapply(data, `[[`, "mean"),
      sample.nobs=lapply(data, `[[`, "nobs"),
      group.equal=equal,
      std.lv=FALSE, meanstructure=TRUE, estimator="ML", ncpus=1)
}

params_for_group <- function(fit, group_id) {
  pe <- parameterEstimates(fit)
  loadings <- pe[pe$op == "=~" & pe$lhs == "F" & pe$group == group_id, c("rhs", "est")]
  intercepts <- pe[pe$op == "~1" & pe$lhs %in% IDS & pe$group == group_id, c("lhs", "est")]
  names(loadings) <- c("item", "loading")
  names(intercepts) <- c("item", "intercept")
  merge(loadings, intercepts, by="item", all=TRUE)
}

wrap_label <- function(prefix, text, width) {
  paste(strwrap(paste(prefix, text), width=width), collapse="\n")
}

item_label <- function(item, spanish_col, width) {
  row <- translations[translations$item_id == item,]
  paste(
    wrap_label("EN:", row$english, width),
    wrap_label("ES:", row[[spanish_col]], width),
    sep="\n"
  )
}

plot_lines <- function(params, items, title, subtitle, path, layout=NULL, ylim=NULL,
                       spanish_col="spanish_faithful", change_note=NULL) {
  theta <- seq(-2, 2, length.out=101)
  en <- params_for_group(params, 1)
  es <- params_for_group(params, 2)
  en$language <- "English"
  es$language <- "Spanish"
  both <- rbind(en, es)

  if (is.null(ylim)) {
    yvals <- unlist(lapply(seq_len(nrow(both)), function(i) {
      both$intercept[i] + both$loading[i] * theta
    }))
    ylim <- range(yvals, na.rm=TRUE)
  }

  png(path, width=1800, height=1500, res=220)
  old_par <- par(no.readonly=TRUE)
  on.exit({ par(old_par); dev.off() }, add=TRUE)

  if (!is.null(layout)) {
    par(mfrow=layout, mar=c(3.2, 3.8, 4.4, 1), oma=c(0, 0, 5.0, 0))
  } else {
    par(mar=c(8.8, 4.2, 5.4, 1), oma=c(0, 0, 4.0, 0))
  }

  for (item in items) {
    e1 <- both[both$item == item & both$language == "English",]
    e2 <- both[both$item == item & both$language == "Spanish",]
    y1 <- e1$intercept + e1$loading * theta
    y2 <- e2$intercept + e2$loading * theta

    plot(theta, y1, type="l", lwd=2.6, col="#1f5a99", ylim=ylim,
         xlab=expression(theta), ylab="Expected pseudo-response",
         main="", cex.lab=if (!is.null(layout)) 0.72 else 1,
         cex.axis=if (!is.null(layout)) 0.78 else 1)
    lines(theta, y2, lwd=2.6, col="#c23b22")
    abline(v=0, col="gray85", lty=3)
    grid(col="gray90", lty=1)
    title(main=item, line=2.75, cex.main=1.05)
    label_width <- if (!is.null(layout)) 48 else 78
    mtext(item_label(item, spanish_col, label_width), side=3, line=0.45,
          adj=0, cex=if (!is.null(layout)) 0.42 else 0.7)
    legend("topleft", legend=c("English", "Spanish"), lwd=2.6,
           col=c("#1f5a99", "#c23b22"), bty="n", cex=0.82)
    if (is.null(layout) && !is.null(change_note)) {
      note <- paste(strwrap(change_note, width=112), collapse="\n")
      mtext(note, side=1, line=6.0, adj=0, cex=0.7)
    }
  }

  mtext(title, outer=TRUE, line=2.4, cex=1.15, font=2)
  if (nzchar(subtitle)) {
    mtext(subtitle, outer=TRUE, line=1.1, cex=0.82)
  }
}

en <- load_cosim("en")
es <- load_cosim("es")
es_an <- load_cosim("es_an")
es_dial <- load_cosim("es_dial")

fit_correct <- fit_free(en, es, pmeans$es)
fit_loading <- fit_free(en, es_an, pmeans$es_an)
fit_intercept_metric <- fit_mg(en, es_dial, pmeans$es_dial, "loadings")

plot_lines(
  fit_correct,
  IDS,
  "Expected pseudo-response by item: faithful English and Spanish versions",
  "Lines are model-implied intercept + loading x theta from the freely estimated two-group CFA.",
  file.path(PLOT_DIR, "expected_response_all_items_correct.png"),
  layout=c(4, 2)
)

plot_lines(
  fit_loading,
  "SCUP32",
  "Metric/loading violation: SCUP32",
  "The Spanish item is a different construct; the non-parallel slope is the visual signal.",
  file.path(PLOT_DIR, "metric_violation_scup32.png"),
  spanish_col="spanish_loading_condition",
  change_note=paste(
    "Change made: replaced the faithful Spanish translation",
    "\"Tener experiencias extrañas.\" with the Spanish translation of",
    "\"See how far I can push people.\" Why: this deliberately changes the",
    "construct-to-item relation, so it should appear as a metric/loading problem."
  )
)

plot_lines(
  fit_intercept_metric,
  "SCEC34",
  "Scalar/intercept violation: SCEC34",
  "Using the metric-constrained model, equal slopes make the item-location shift visible as parallel lines.",
  file.path(PLOT_DIR, "scalar_violation_scec34.png"),
  spanish_col="spanish_intercept_condition",
  change_note=paste(
    "Change made: replaced the faithful Spanish translation",
    "\"Parece excéntrico a otras personas.\" with",
    "\"Parece original para otras personas.\" Why: this keeps the item broadly",
    "on the same construct but dials back intensity/location, so it should",
    "appear as a scalar/intercept problem."
  )
)

cat("Plots written to:\n")
cat("  ", file.path(PLOT_DIR, "expected_response_all_items_correct.png"), "\n", sep="")
cat("  ", file.path(PLOT_DIR, "metric_violation_scup32.png"), "\n", sep="")
cat("  ", file.path(PLOT_DIR, "scalar_violation_scec34.png"), "\n", sep="")
