suppressPackageStartupMessages(library(lavaan))

# This R environment can report parallel::detectCores() as NA, which makes
# lavaan 0.6-19 cache an invalid ncpus default before model fitting.
invisible(lavOptions())
lavaan_cache <- get("lavaan_cache_env", asNamespace("lavaan"))
lavaan_defaults <- get("opt.default", lavaan_cache)
lavaan_checks <- get("opt.check", lavaan_cache)
lavaan_defaults$ncpus <- 1L
lavaan_checks$ncpus$nm$bounds <- c(1, 1)
assign("opt.default", lavaan_defaults, lavaan_cache)
assign("opt.check", lavaan_checks, lavaan_cache)

args <- commandArgs(FALSE)
file_arg <- args[grepl("^--file=", args)]
DIR <- if (length(file_arg) > 0) {
  dirname(normalizePath(sub("^--file=", "", file_arg[1])))
} else {
  getwd()
}

IDS <- c("SCUP104","SCCD71","SCUB69","SCEC34","SCDS108","SCUP32","SCEC106","SCDS72")

load_cosim <- function(tag) {
  m <- as.matrix(read.csv(file.path(DIR, paste0("cosim_", tag, ".csv")), row.names=1))
  colnames(m) <- rownames(m) <- IDS
  m
}

pmeans <- read.csv(file.path(DIR, "pmeans.csv"))

build_data <- function(en_mat, es_mat, en_pm, es_pm) {
  list(en=list(cov=en_mat, mean=en_pm, nobs=length(IDS)),
       es=list(cov=es_mat, mean=es_pm, nobs=length(IDS)))
}

model <- paste("F =~", paste(IDS, collapse=" + "), "\nF ~ c(0,NA)*1\nF ~~ c(1,NA)*F")

fit_mg <- function(data, equal) {
  sem(model, sample.cov=lapply(data, `[[`, "cov"),
      sample.mean=lapply(data, `[[`, "mean"),
      sample.nobs=lapply(data, `[[`, "nobs"),
      group.equal=equal, std.lv=FALSE, meanstructure=TRUE, estimator="ML",
      ncpus=1)
}

save_summary <- function(fit, path) capture.output(
  print(summary(fit, standardized=TRUE, fit.measures=TRUE, rsquare=TRUE)),
  file=path)

analyse <- function(en_mat, es_mat, es_pm, label, tag) {
  cat("\n", label, "\n", sep="")
  d   <- build_data(en_mat, es_mat, pmeans$en, es_pm)
  cfg <- fit_mg(d, character(0))
  met <- fit_mg(d, "loadings")
  sca <- fit_mg(d, c("loadings","intercepts"))
  save_summary(cfg, file.path(DIR, paste0("summary_", tag, "_configural.txt")))
  save_summary(met, file.path(DIR, paste0("summary_", tag, "_metric.txt")))
  save_summary(sca, file.path(DIR, paste0("summary_", tag, "_scalar.txt")))

  cov_met <- sapply(lavInspect(met,"residuals"), function(x) diag(x$cov))
  mea_sca <- sapply(lavInspect(sca,"residuals"), function(x) x$mean)

  out <- data.frame(
    item      = IDS,
    met.ld.EN = round(cov_met[,1],3), met.ld.ES = round(cov_met[,2],3),
    sca.in.EN = round(mea_sca[,1],3), sca.in.ES = round(mea_sca[,2],3)
  )
  print(out, row.names=FALSE)
  write.csv(out, file.path(DIR, paste0("residuals_", tag, ".csv")), row.names=FALSE)

  ss      <- standardizedSolution(sca)
  lm_diff <- ss[ss$lhs=="F" & ss$op=="~1" & ss$group==2, "est.std"]
  lm_out <- data.frame(condition=tag, latent_mean_es_minus_en_std=round(lm_diff, 3))
  write.csv(lm_out, file.path(DIR, paste0("latent_mean_", tag, ".csv")), row.names=FALSE)
  cat("Latent mean difference (ES - EN, standardised):", round(lm_diff, 3), "\n")
}

en      <- load_cosim("en")
es      <- load_cosim("es")
es_an   <- load_cosim("es_an")
es_dial <- load_cosim("es_dial")

analyse(en, es,      pmeans$es,      "CORRECT - items match",                                          "correct")
analyse(en, es_an,   pmeans$es_an,   "ITEM SWITCHED - SCUP32 replaced with wrong-construct item in ES", "loading")
analyse(en, es_dial, pmeans$es_dial, "ITEM DIALLED BACK - SCEC34 replaced with lower-intensity in ES",  "intercept")
