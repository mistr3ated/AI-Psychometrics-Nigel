PSEUDO MEASUREMENT INVARIANCE

This folder contains the current self-contained analysis for a small
pseudo-measurement-invariance demonstration.

The example uses 8 English HEXACO Schizotypy items and Spanish translations.
Item embeddings are converted into cosine similarity matrices and pseudo mean
vectors, then fitted as two-group CFA models in lavaan:

  Configural: same factor structure across English and Spanish
  Metric:     loadings constrained equal across languages
  Scalar:     loadings and intercepts constrained equal across languages

Because these are pseudo-data, there is no real respondent sample size. The
diagnostic evidence is therefore descriptive: per-item residuals are inspected
directly rather than using chi-square p-values or sample-size-dependent fit
indices.

Run order:

  /opt/anaconda3/bin/python prepare.py
  Rscript fit.R
  Rscript make_plots.R

Key files:

  prepare.py
    Translates the English items, embeds English and Spanish texts, writes
    cosine matrices, pseudo means, and item_translations.csv.

  fit.R
    Fits configural, metric, and scalar two-group CFA models. Writes lavaan
    summaries, residual tables, and latent mean CSVs.

  make_plots.R
    Creates expected pseudo-response plots from model-implied intercepts and
    loadings.

Main outputs:

  item_translations.csv
  cosim_en.csv, cosim_es.csv, cosim_es_an.csv, cosim_es_dial.csv
  pmeans.csv
  residuals_correct.csv
  residuals_loading.csv
  residuals_intercept.csv
  latent_mean_correct.csv
  latent_mean_loading.csv
  latent_mean_intercept.csv
  summary_*_configural.txt
  summary_*_metric.txt
  summary_*_scalar.txt
  plots/expected_response_all_items_correct.png
  plots/metric_violation_scup32.png
  plots/scalar_violation_scec34.png

Result check:

  Correct condition:
    Residuals remain comparatively small and stable.

  Loading corruption:
    SCUP32 has the standout metric loading residual in Spanish:
    met.ld.ES = -0.495, sca.in.ES = -1.675

  Intercept corruption:
    SCEC34 has the standout scalar intercept residual in Spanish:
    met.ld.ES = -0.156, sca.in.ES = -0.419

Interpretation:

  The loading corruption replaces the Spanish counterpart of "Have bizarre
  experiences" with a translation of "See how far I can push people." This
  changes the item-construct relation and is detected as a metric/loading
  problem.

  The intercept corruption replaces the Spanish counterpart of "Seem eccentric
  to other people" with "Seem original to other people." This keeps the item
  broadly related to social unusualness but lowers its intensity/location, and
  is detected as a scalar/intercept problem.

